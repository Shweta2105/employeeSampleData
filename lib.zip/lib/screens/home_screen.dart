import 'package:employee_data/services/services.dart';
import 'package:flutter/material.dart';

import '../models/post_employee.dart';
import 'detail_screen.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with TickerProviderStateMixin {
  EmployeePost? data;
  List<Datum>? employeeData;
  var isLoaded = false;
  late TabController _tabController;
  final List<String> categories = const [
    'Business',
    'Entertainment',
    'General',
    'Health',
    'Science',
    'Sports',
    'Technology'
  ];
  final List<String> subCategories = const [
    'First Name',
    'Last Name',
        'Title',
    'Email'
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: categories.length, vsync: this);
    getData();

  }
getData() async{
    data=await Services().getPost();
    if(data!=null)
      {
        setState(() {
          isLoaded=true;
        });
      }
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Page', style: TextStyle(color: Colors.white)),
        actions: [
          TextButton(
              onPressed: () {},
              child: const Text(
                'Refresh',
                style: TextStyle(color: Colors.white),
              ))
        ],
        bottom: TabBar(
            isScrollable: true,
            controller: _tabController,
            tabs: data!.data
                .map((e) => Text(
                      e.firstName!,
                      style: TextStyle(color: Colors.white),
                    ))
                .toList()),
      ),
      body: TabBarView(
        controller: _tabController,
        children:categories
            .map((e) => ListView.builder(
          itemCount: data!.data.length,
              itemBuilder: (context, snapshot) {
                return DetailedView(
                      categories:data!.data[snapshot],
                    );
              },
            ))
            .toList(),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
