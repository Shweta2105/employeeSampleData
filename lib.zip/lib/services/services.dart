import 'package:employee_data/models/post_employee.dart';
import 'package:http/http.dart' as http;

class Services {
  Future<EmployeePost?> getPost() async {
    var data = http.Client();
    var uri = Uri.parse('https://reqres.in/api/users?page=1');
  var response= await data.get(uri);
  if(response.statusCode==200)
  {
    var json=response.body;
    return employeePostFromJson(json);
  }

  }
}
